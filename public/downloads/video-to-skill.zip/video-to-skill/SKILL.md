---
name: video-to-skill
description: Use when turning a YouTube video, podcast, talk, webinar, or audio file into a comprehensive written guide with diagrams and, optionally, a reusable Claude skill. Triggers on "video to skill", "learn from this video", "make a guide from this video", "summarize this video", "turn this podcast into a guide", "make a skill from this".
---

# Video-to-Skill

Turn any video, podcast or talk into a comprehensive, visual guide you can actually use in
your business, and optionally into a reusable Claude skill that applies what the expert taught.

**Usage:** `/video-to-skill [YouTube URL, podcast URL, audio URL, or local audio/video file]`

**Supported inputs**
- YouTube URL: transcript fetched from YouTube's captions with `scripts/get_transcript.py`
- Podcast page URL: find the MP3 on the page, download it, transcribe with Whisper
- Direct MP3 / M4A / WAV URL: download and transcribe with Whisper
- Local file (`.mp3`, `.m4a`, `.mp4`, `.mov`): transcribe with Whisper
- Facebook, Vimeo, TikTok, Instagram video URL: download audio with `yt-dlp`, transcribe with Whisper

**Everything this skill produces lands in one folder:**
`~/Downloads/Video Skills/[Topic Title]/`

No other folder on the machine is touched, except when the user chooses "Full Skill", in which
case the finished skill is also installed to `~/.claude/skills/[topic-slug]/SKILL.md` so Claude
can use it in future sessions. Always tell the user before installing anything.

---

## What this produces

| Mode | Output |
|---|---|
| **Full Skill** (default) | `transcript.txt` + `[topic]-guide.md` + `[topic]-guide.html` + `SKILL.md` + `README.md`, and the skill installed for Claude |
| **Guide Only** | `transcript.txt` + `[topic]-guide.md` + `[topic]-guide.html` + `README.md` |
| **Quick Summary** | A written summary in the chat. Nothing saved. |

---

## The process

### Step 0: Ask what's needed

Before doing anything, ask:

> **What do you need from this video?**
> 1. **Full Skill** — transcript + comprehensive visual guide + a reusable Claude skill that applies the method *(default: use for a methodology you'll apply repeatedly)*
> 2. **Guide Only** — transcript + comprehensive visual guide *(use for training material, SOPs, reference docs, one-time learning)*
> 3. **Quick Summary** — key points in the chat, nothing saved *(use when you only need to know what's in it)*

If the user gives a URL with no other context, default to **Full Skill**.

- Full Skill: all steps
- Guide Only: Steps 1–5, then Step 8
- Quick Summary: Step 2 only, then summarize in the chat

### Step 1: Create the output folder

```bash
mkdir -p ~/Downloads/"Video Skills"/"[Topic Title]"
```

`[Topic Title]` is Title Case, 3–7 words, describing the topic rather than the video title.
Example: `~/Downloads/Video Skills/Email Copywriting That Converts/`

Refer to this as `[OUT]` for the rest of the process.

### Step 2: Get the transcript, save to `[OUT]/transcript.txt`

Detect the input type first.

**YouTube URL** (captions available, which is most videos):
```bash
python3 "$SKILL_DIR/scripts/get_transcript.py" "[URL]" --output "[OUT]/transcript.txt"
```
`$SKILL_DIR` is the folder this SKILL.md lives in, normally `~/.claude/skills/video-to-skill`.
The script installs `youtube-transcript-api` on first run if it is missing.

**YouTube URL with no captions, or Facebook / Vimeo / TikTok / Instagram:**
```bash
yt-dlp -x --audio-format mp3 -o "[OUT]/source-audio.%(ext)s" "[URL]"
```
then transcribe (below). If `yt-dlp` is missing: `brew install yt-dlp` on macOS, `pip3 install yt-dlp` elsewhere.

**Podcast page URL with no direct MP3:** fetch the page (WebFetch) and ask for "any audio file URL (MP3, M4A) on this page", then treat it as a direct audio URL.

**Direct audio URL:**
```bash
curl -L "[AUDIO_URL]" -o "[OUT]/source-audio.mp3"
```

**Transcribe any audio or local file with Whisper (runs locally, no API key):**
```bash
whisper "[OUT]/source-audio.mp3" --model base --output_format txt --output_dir "[OUT]"
mv "[OUT]/source-audio.txt" "[OUT]/transcript.txt"
```
If `whisper` is not on the PATH, try `python3 -m whisper` and, failing that, tell the user how to install it:
```bash
brew install ffmpeg          # macOS; on Windows/Linux install ffmpeg from ffmpeg.org
pip3 install openai-whisper
```
`base` is fast and accurate enough for clear spoken English. Use `small` or `medium` for heavy
accents or technical jargon. A one-hour episode takes a few minutes on `base`.

**If no transcript can be obtained at all:** say so plainly, then build the guide from the video
description, any published show notes, and web research. Mark the guide "transcript unavailable"
at the top. Never invent quotes.

### Step 3: Research the speaker and the topic

Use web search (WebSearch / WebFetch) to establish:
- Who the speaker is: background, credentials, track record, published work
- Named frameworks or books they are known for
- Supplementary frameworks on the same topic from other credible sources
- Additional named examples beyond the ones in the video
- Any criticism or counterpoints worth noting
- **What changed since the video was recorded** (product updates, pricing, new features). For anything about AI tools or software, assume a video older than a month is partly out of date and check.

Keep a list of every source URL you used. It goes in the guide.

### Step 4: Analyze the transcript for teachable structure

Extract:
- **Core frameworks**: named or unnamed systems the speaker uses
- **Step-by-step processes**: sequences that can be replicated
- **Principles**: the "why" behind the tactics
- **Named examples**: specific case studies with outcomes
- **Quotes**: verbatim lines worth preserving
- **Mistakes and anti-patterns**: what not to do
- **Tools and resources** mentioned

### Step 5: Write the guide, then build and verify the HTML

> Read `$SKILL_DIR/GUIDE-STANDARD.md` before writing. It defines the structure, the diagram
> rules and the build/verify steps.

File: `[OUT]/[topic]-guide.md`

Structure (full version in GUIDE-STANDARD.md):

```markdown
# [Title]
## [Speaker] on [Source]

Source · Speaker · Guide created · Prepared with video-to-skill

> Framing note: why this guide exists in this shape

## Table of Contents          ← grouped into Parts, anchor-linked

# PART I — ORIENTATION
1. Who is [Speaker], and why listen
2. The central claim
3. What changed since this was recorded    ← mandatory if the source is over a month old

# PART II … N — THE CONTENT
   One section per framework: what it is → verbatim quotes → diagram → how to apply

# PART — APPLICATION
   Applying this in your business   ← their tool | what it costs | a free or cheaper alternative | what you give up
   Evaluation checklist             ← checkboxes; every "no" is a to-do
   Common mistakes                  ← ❌ Mistake | ✅ Fix | § reference
   First-week plan                  ← Day 1–5, using only tools that exist today
   Key quotes
   Sources and verification         ← including what you could NOT verify
```

**Quality bar:** a reference document, not a summary. 8,000–12,000 words for a full methodology,
proportionally shorter for a short talk. Quote verbatim and often, bolding the operative clause.
Report results honestly. Flag anything now out of date.

**Diagrams are mandatory.** 8–20 Mermaid diagrams per guide, inline in the `.md` as
```` ```mermaid ```` fences: concepts, processes, comparisons, timelines. `flowchart TB` by
default. Style key nodes with the palette in GUIDE-STANDARD.md. Never ship an all-grey diagram.

> **The width rule.** A `flowchart LR` with more than about 5 chained nodes renders as an
> unreadable smear in a 900px column and throws no error. Keep every diagram under 1350px
> natural width. Use `flowchart TB`. The verifier catches violations.

**Build the HTML** (one self-contained file, works offline, opens anywhere):
```bash
python3 "$SKILL_DIR/scripts/build_guide_html.py" "[OUT]/[topic]-guide.md" "[OUT]/[topic]-guide.html"
```
Requires the `markdown` package: `pip3 install markdown` if the build complains.

**Verify it** (never skip):
```bash
python3 "$SKILL_DIR/scripts/verify_guide_html.py" "[OUT]/[topic]-guide.html"
```
It must print **✅ PASS** before you tell the user the guide is done. With Playwright installed
it renders the page in a real browser and checks every diagram; without it, it runs static
checks and says so. To get the full check: `pip3 install playwright && python3 -m playwright install chromium`.

### Step 6: Write the skill (Full Skill only)

File: `[OUT]/SKILL.md`

**The skill encodes the method, not the content.** It tells Claude how to apply the expert's
framework when helping with a real task.

```markdown
---
name: [topic-slug]
description: Use when [specific triggering situations]. Triggers on "[phrase 1]", "[phrase 2]", "[phrase 3]".
---

# [Title] — [Speaker]'s method

[One line: what this skill enables]

**Full guide:** ~/Downloads/Video Skills/[Topic Title]/[topic]-guide.html

## [Core step 1]
[Actionable instructions]

## [Core step 2]
…

## Quick reference
[Table of the key frameworks and rules]

## Common mistakes
[Table: Mistake → Fix]
```

Rules: the description says **when** to use it, not what it does. Each section is one
actionable step. Include the named examples as quick reference. Keep it under 300 lines and
link to the guide for depth.

### Step 7: Install the skill (Full Skill only)

Tell the user what you are about to do, then:
```bash
mkdir -p ~/.claude/skills/[topic-slug]
cp "[OUT]/SKILL.md" ~/.claude/skills/[topic-slug]/SKILL.md
```
The skill is available in the next Claude Code session as `/[topic-slug]` and by its trigger phrases.

### Step 8: Write the README and deliver

File: `[OUT]/README.md`

```markdown
# [Title]

**Speaker:** [Name]
**Source:** [Title / URL]
**Created:** [Date]

## What's in this folder
| File | Purpose |
|---|---|
| `[topic]-guide.html` | The guide. Open this. Works offline. |
| `[topic]-guide.md` | The same guide as Markdown, for editing or pasting elsewhere |
| `transcript.txt` | The full transcript |
| `SKILL.md` | The Claude skill (Full Skill only). Installed at `~/.claude/skills/[topic-slug]/` |

## How to use the skill
Say "[trigger phrase]" or type `/[topic-slug]` in Claude Code.

## The method in five lines
- …
```

Then report to the user:

```
## ✅ Done: [Title]

**Speaker:** [Name]   **Source:** [URL]

**What was learned**
- [Framework 1]
- [Framework 2]
- [Key insight]

**Files** (~/Downloads/Video Skills/[Topic Title]/)
- [topic]-guide.html   ← open this
- [topic]-guide.md
- transcript.txt
- SKILL.md + README.md (Full Skill only)

**Skill installed:** ~/.claude/skills/[topic-slug]/  — say "[trigger phrase]" or type /[topic-slug]
```

---

## Quality standards

- The guide is comprehensive: a reference document, not a summary
- Visual by default: 8–20 Mermaid diagrams, none over 1350px wide, `flowchart TB` unless the chain is 5 nodes or fewer
- Every named example: what it was → what the alternative was → what the outcome was
- Every framework usable without watching the video
- A "What changed since this was recorded" section whenever the source is over a month old
- An "Applying this in your business" section with costs and a cheaper alternative for every tool
- Skills stay concise: 100–300 lines, linking to the guide for depth
- `verify_guide_html.py` prints ✅ PASS before you report done

## Error handling

- **No captions and no Whisper:** build from description, show notes and research; mark the guide "transcript unavailable"
- **Speaker not findable:** build from the content alone; note the research limitation
- **Technical, code-heavy video:** add a "Quick start" section with working code examples
- **Very long source (over 3 hours):** ask whether to cover all of it or a chosen segment before transcribing
